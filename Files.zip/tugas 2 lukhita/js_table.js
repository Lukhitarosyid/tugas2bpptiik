    var isidat = "";
    var arrnam = new Array();
    var arrnil = new Array();

function terimainput(){

    var y=document.forms['nilaisiswa']['nama'].value;
    var x=document.forms['nilaisiswa']['nsiswa'].value;
   
    arrnam.push(y);
    arrnil.push(x);

                                      
    var tabel = document.getElementById("datatab");
    
            for(var i = 0; i < arrnil.length; i++){
                var z ="<input type='reset' value='delete' onclick='hapusdata("+(i)+")'>";
                isidat+="<tr><td>"+arrnam[i]+"</td><td>"+arrnil[i]+"</td><td>"+z+"</td></tr>"

            }
            tabel.innerHTML = isidat;
            isidat = "";
        } 
function hapusdata(index){
    arrnam.splice(index,1);
    arrnil.splice(index,1);
    var tabel = document.getElementById("datatab");

    for(var i = 0; i < arrnil.length; i++){
        var z ="<input type ='reset' value='delete' onclick='hapusdata("+(i)+")'>";    
        isidat+="<tr><td>"+arrnam[i]+"</td><td>"+arrnil[i]+"</td><td>"+z+"</td></tr>"    
}
tabel.innerHTML =isidat;
isidat ="";
   
}